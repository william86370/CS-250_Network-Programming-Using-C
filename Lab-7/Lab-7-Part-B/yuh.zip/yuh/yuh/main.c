#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define maxchars 41
int main() {
    char * filename[20];
    FILE *pptr;
    FILE *nptr;
    char * line = NULL;
    FILE *fp;
    size_t len =0;
    ssize_t read;
    pptr = fopen("PalindromeOut.txt","w");
    nptr = fopen("QuotesOut.txt","w");
    printf("Enter a FileName To Be Scanned For Palindromes:");
  scanf("%s", filename);
    fp = fopen(filename,"r");
    while ((read = getline(&line, &len, fp)) != -1)
    {
        char * message = NULL;
        char letters[maxchars] = {'\0'};
        char specialchars[maxchars] = {'\0'};
        int countinput = 0;
        int countletters = 0;
        int countspecial = 0;
        int palindromeloop = 0;
        char (*p)[maxchars] = &letters;
        int i=0, j=0, k=0, l=0;
        message=line;
        printf("%s", message);
    /*  As newline characters are also counted with strlen(), a potential '\n' character needs to be replaced with the null terminator.  */
    for (i=0;i<maxchars;i++) {
        if(message[i] == '\n') {
            message[i] = '\0';
            break;
        }
    }
    countinput = strlen(message);
    for(i=0;i<countinput;i++) {
        if( (message[i] >= 65 && message[i] <= 90) || (message[i] >= 97 && message[i] <= 122) ) {
            letters[j] = tolower(message[i]);
            j++;
        } else {
            specialchars[l] = message[i];
            l++;
        }
    }
    countletters = strlen(letters);
    countspecial = strlen(specialchars);
        int yuh=0;
    if(countletters > 0) {
       
        palindromeloop = countinput / 2;
        for(i=0;i<palindromeloop;i++) {
         
            if ( (*p)[i] != (*p)[countletters-i-1]) {
                printf("this line was Not a palindrome\n");
                fprintf(nptr,"%s \n",message);
                yuh=1;
                k = 1;
                i = palindromeloop;
                
            }
        }
        if(yuh==0){
              printf("this line was a Palindrome\n"); // else print confirmation
             fprintf(pptr,"%s \n",message);
        }
        
        // input is a palindrome if there are only special characters
    } else if (countspecial > 0) {
        printf("this line was a Palindrome\n");
        
        
        // input is not a palindrome if there are no printable characters
    } else {
        printf("this line was Not a palindrome\n");
        
    }
    }
    fclose(pptr);
    fclose(nptr);
    fclose(fp);
    return(1);
}




